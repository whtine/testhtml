const products = $.ajax('/underscore/db/products.json');
const sales = $.ajax('/underscore/db/sales.json');
const template = $.ajax('/underscore/template/product.html');

$.when(products, sales, template).done(function (products, sales, template) {
  const productsDone = products[0];
  const salesDone = sales[0];
  const templateDone = template[0];
  const templateFun = _.template(templateDone);

  renderProducts(productsDone)

  function renderProducts(productsDone) {
    const catalog = $('.catalog-body');

    for (let index = 0; index < productsDone.length; index++) {
      const product = productsDone[index];
      product.isSale = false;
      const sale = salesDone.find((sale) => sale.product_id === product.id);

      if (sale) {
        product.isSale = true;
        product.salePrice = sale.sale_amount;
      }

      const html = templateFun(product);
      catalog.append(html)
    }

  }

  function gender(productsDone, salesDone, templateFun, renderProducts) {
    const catalog = $('.catalog-body');
    const genderButtons = document.querySelectorAll('.filter-option');


    function renderFilteredProducts(filteredProducts) {
      catalog.empty();
      filteredProducts.forEach(product => {
        product.isSale = false;
        const sale = salesDone.find(sale => sale.product_id === product.id);
        if (sale) {
          product.isSale = true;
          product.salePrice = sale.sale_amount;
        }
        const html = templateFun(product);
        catalog.append(html);
      });
    }

    genderButtons.forEach(button => {
      button.addEventListener("click", function () {
        const selectedGender = button.getAttribute("data-value");
        const filtered = _.filter(productsDone, product => product.gender === selectedGender);
        console.log(`${selectedGender} products:`, filtered);
        renderFilteredProducts(filtered);
      });
    });

    function getPriceValue(item) {
      return item.isSale ? item.salePrice : item.Price;
    }

    function getFilterData() {
      let filtered = productsDone;

      filtered = filtered.filter((item) => {
            const price = getPriceValue(item);
            const priceFrom = filterValue.priceFrom;
            const priceTo = filterValue.priceTo;

            return (!priceFrom || price >= priceFrom) && (!priceTo || price <= priceTo)
        })

      if (filterValue.gender) {
        filtered = filtered.filter((item) => item.gender === filterValue.gender);
      }

      if (filterValue.color) {
        filtered = filtered.filter((item) => item.color === filterValue.color);
      }
      if (filterValue.fromPrice) {
        filtered = filtered.filter((item) => item.price >= filterValue.fromPrice);
      }
      if (filterValue.toPrice) {
        filtered = filtered.filter((item) => item.price <= filterValue.toPrice);
      }
      if (filterValue.fromSalePrice) {
        filtered = filtered.filter(item => item.salePrice >= filterValue.fromSalePrice);
      }
      if (filterValue.toSalePrice) {
        filtered = filtered.filter(item => item.salePrice <= filterValue.toSalePrice);
      }

      return filtered;
    }

    $('.filter-option').on('click', function () {
      const gender = $(this).data("value");

      if (filterValue.gender === gender) {
        delete filterValue.gender;
      } else {
        filterValue.gender = gender;
      }

      const getFiltered = getFilterData();
      renderFilteredProducts(getFiltered);
    });
    $('.color-item').on('click', function () {
      const input = $(this).children('input');
      const inputColor = input.val();
      if (inputColor === "#ff0000") {
        filterValue.color = "red";
      } else {
        filterValue.color = inputColor;
      }
      const getFiltered = getFilterData();
      console.log(getFiltered);
      renderFilteredProducts(getFiltered);
    });

    $('#price-from').on('change', function () {
      const fromInput = $("#price-from")
      const inputFromNumber = fromInput.val();

      filterValue.fromPrice = +inputFromNumber;
      const getFiltered = getFilterData();

      renderFilteredProducts(getFiltered);
    });
    $('#price-to').on('change', function () {
      const toInput = $("#price-to")
      const inputToNumber = toInput.val();

      filterValue.toPrice = +inputToNumber;
      const getFiltered = getFilterData();

      renderFilteredProducts(getFiltered);
    });
    $('#sale-from').on('change', function () {
      const fromSaleInput = $("#sale-from")
      const inputFromSaleNumber = fromSaleInput.val();

      filterValue.fromSalePrice = +inputFromSaleNumber;
      const getFiltered = getFilterData();

      renderFilteredProducts(getFiltered);
      console.log(getFiltered);
    });
    $('#sale-to').on('change', function () {
      const toSaleInput = $("#sale-to")
      const inputToSaleNumber = toSaleInput.val();

      filterValue.toSalePrice = +inputToSaleNumber;
      const getFiltered = getFilterData();

      renderFilteredProducts(getFiltered);
    });

  }
  gender(productsDone, salesDone, templateFun);
})

let filterValue = {}


